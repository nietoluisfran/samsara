package sominie.samsara.java.dao;

import sominie.samsara.java.entities.Producto;
import sominie.samsara.java.interfaces.ProductoDAO;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProductoDAOImpl implements ProductoDAO {

    private Connection conn;

    public ProductoDAOImpl(Connection conn) {
        this.conn = conn;
    }

    @Override
    public void crearProducto(Producto producto) {
        String query = "INSERT INTO productos (codigo, articulo, marca, precio, stock) VALUES (?, ?, ?, ?, ?)";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, producto.getCodigo());
            ps.setString(2, producto.getArticulo());
            ps.setString(3, producto.getMarca());
            ps.setDouble(4, producto.getPrecio());
            ps.setInt(5, producto.getStock());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public Producto buscarProductoPorCodigo(int codigo) {
        Producto producto = null;
        String query = "SELECT * FROM productos WHERE codigo = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, codigo);
            ResultSet rs = ps.executeQuery();
            if (rs.next()) {
                int codigoDB = rs.getInt("codigo");
                String articulo = rs.getString("articulo");
                String marca = rs.getString("marca");
                double precio = rs.getDouble("precio");
                int stock = rs.getInt("stock");
                producto = new Producto(codigoDB, articulo, marca, precio, stock);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return producto;
    }

    @Override
    public List<Producto> listarProductos() {
        List<Producto> productos = new ArrayList<>();
        String query = "SELECT * FROM productos";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ResultSet rs = ps.executeQuery();
            while (rs.next()) {
                int codigo = rs.getInt("codigo");
                String articulo = rs.getString("articulo");
                String marca = rs.getString("marca");
                double precio = rs.getDouble("precio");
                int stock = rs.getInt("stock");
                Producto producto = new Producto(codigo, articulo, marca, precio, stock);
                productos.add(producto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return productos;
    }

    @Override
    public void actualizarProducto(Producto producto) {
        String query = "UPDATE productos SET articulo = ?, marca = ?, precio = ?, stock = ? WHERE codigo = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setString(1, producto.getArticulo());
            ps.setString(2, producto.getMarca());
            ps.setDouble(3, producto.getPrecio());
            ps.setInt(4, producto.getStock());
            ps.setInt(5, producto.getCodigo());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void eliminarProducto(Producto producto) {
        String query = "DELETE FROM productos WHERE codigo = ?";
        try {
            PreparedStatement ps = conn.prepareStatement(query);
            ps.setInt(1, producto.getCodigo());
            ps.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void insertarProducto(Producto nuevoProducto) {
        crearProducto(nuevoProducto);
    }

}
