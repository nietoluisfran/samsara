
package sominie.samsara.java.interfaces;

import sominie.samsara.java.entities.Producto;
import java.util.List;

public interface ProductoDAO {
    public void crearProducto(Producto producto);
    public Producto buscarProductoPorCodigo(int codigo);
    public List<Producto> listarProductos();
    public void actualizarProducto(Producto producto);
    public void eliminarProducto(Producto producto);

    public void insertarProducto(Producto nuevoProducto);
}
